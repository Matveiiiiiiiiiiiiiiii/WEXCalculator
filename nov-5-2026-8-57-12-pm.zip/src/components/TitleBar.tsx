import React, { useState } from 'react';
import { Language, LANGUAGES, getTranslation } from '../utils/i18n';
import { UserProfile, CalculatorMode } from '../types/calculator';
import {
  Calculator,
  Volume2,
  VolumeX,
  Sun,
  Moon,
  Laptop,
  Maximize2,
  Minimize2,
  History,
  HelpCircle,
  Pin,
  Settings,
  Camera,
  Globe,
  LineChart,
  User as UserIcon,
  Zap,
} from 'lucide-react';

interface TitleBarProps {
  osTheme: 'windows' | 'macos';
  setOsTheme: (theme: 'windows' | 'macos') => void;
  isDark: boolean;
  setIsDark: (dark: boolean) => void;
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
  isPinned: boolean;
  setIsPinned: (val: boolean) => void;
  isFullscreen: boolean;
  setIsFullscreen: (val: boolean) => void;
  showHistory: boolean;
  setShowHistory: (val: boolean) => void;
  historyCount: number;
  onOpenShortcuts: () => void;
  onOpenSettings: () => void;
  onOpenPhotoMath: () => void;
  onOpenQuickAnswers?: () => void;
  lang: Language;
  setLang: (l: Language) => void;
  user: UserProfile | null;
  onOpenAccount: () => void;
  activeMode: CalculatorMode;
  onSelectMode: (mode: CalculatorMode) => void;
}

export const TitleBar: React.FC<TitleBarProps> = ({
  osTheme,
  setOsTheme,
  isDark,
  setIsDark,
  soundEnabled,
  setSoundEnabled,
  isPinned,
  setIsPinned,
  isFullscreen,
  setIsFullscreen,
  showHistory,
  setShowHistory,
  historyCount,
  onOpenShortcuts,
  onOpenSettings,
  onOpenPhotoMath,
  onOpenQuickAnswers,
  lang,
  setLang,
  user,
  onOpenAccount,
  activeMode,
  onSelectMode,
}) => {
  const [showLangMenu, setShowLangMenu] = useState(false);
  const currentLang = LANGUAGES.find((l) => l.code === lang) || LANGUAGES[0];

  return (
    <header
      className={`flex items-center justify-between px-3.5 py-2.5 border-b select-none transition-colors ${
        isDark
          ? 'bg-slate-900/80 border-slate-800 text-slate-200'
          : 'bg-slate-100/90 border-slate-200 text-slate-800'
      } backdrop-blur-md relative z-30`}
    >
      {/* Left side: Window Controls & Title */}
      <div className="flex items-center gap-2.5">
        {osTheme === 'macos' ? (
          <div className="flex items-center gap-1.5 mr-1" aria-label="macOS Controls">
            <span
              className="w-3 h-3 rounded-full bg-red-500 hover:bg-red-600 transition-colors cursor-pointer"
              title="Close"
            />
            <span
              className="w-3 h-3 rounded-full bg-amber-500 hover:bg-amber-600 transition-colors cursor-pointer"
              title="Minimize"
            />
            <span
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="w-3 h-3 rounded-full bg-emerald-500 hover:bg-emerald-600 transition-colors cursor-pointer"
              title="Fullscreen"
            />
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-500/30">
              <Calculator className="w-3.5 h-3.5" />
            </div>
          </div>
        )}

        <div className="flex items-center gap-1.5 min-w-0">
          <span className="font-semibold text-xs tracking-tight truncate">
            {getTranslation('appTitle', lang)}
          </span>
          <span
            className={`text-[9px] sm:text-[10px] px-1.5 py-0.5 rounded-full font-medium shrink-0 ${
              isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-200 text-slate-600'
            }`}
          >
            {osTheme === 'windows' ? 'Win' : 'Mac'}
          </span>
        </div>
      </div>

      {/* Center: Quick Switcher between Calculator and Graphs */}
      <div className="hidden sm:flex items-center p-0.5 rounded-lg border border-inherit/40 bg-slate-500/10">
        <button
          onClick={() => onSelectMode(activeMode === 'graphs' ? 'standard' : activeMode)}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
            activeMode !== 'graphs'
              ? isDark
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-blue-600 shadow-xs'
              : 'opacity-70 hover:opacity-100'
          }`}
          title={getTranslation('calcMode', lang)}
        >
          <Calculator className="w-3.5 h-3.5" />
          <span>{getTranslation('standard', lang)}</span>
        </button>
        <button
          onClick={() => onSelectMode('graphs')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
            activeMode === 'graphs'
              ? isDark
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-blue-600 shadow-xs'
              : 'opacity-70 hover:opacity-100'
          }`}
          title={getTranslation('graphsMode', lang)}
        >
          <LineChart className="w-3.5 h-3.5" />
          <span>{getTranslation('graphs', lang)}</span>
        </button>
      </div>

      {/* Right side: App Actions & System Toggles */}
      <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
        {/* Google Workspace / Account button */}
        <button
          onClick={onOpenAccount}
          className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
            user
              ? isDark
                ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30 hover:bg-blue-600/30'
                : 'bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100'
              : isDark
              ? 'hover:bg-slate-800 text-slate-300'
              : 'hover:bg-slate-200 text-slate-700'
          }`}
          title={user ? `${user.displayName || user.email}` : getTranslation('account', lang)}
          aria-label={getTranslation('account', lang)}
        >
          {user?.photoURL ? (
            <img
              src={user.photoURL}
              alt={user.displayName || 'User'}
              className="w-4 h-4 rounded-full object-cover shrink-0"
            />
          ) : (
            <UserIcon className="w-3.5 h-3.5 shrink-0 text-blue-500" />
          )}
          <span className="hidden sm:inline font-semibold">
            {user ? (user.displayName?.split(' ')[0] || 'User') : getTranslation('account', lang)}
          </span>
        </button>

        {/* Quick Answers Button */}
        {onOpenQuickAnswers && (
          <button
            onClick={onOpenQuickAnswers}
            className="px-2 py-1 text-[11px] font-semibold rounded-md transition-all flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white shadow-xs cursor-pointer active:scale-95"
            title={lang === 'uk' ? 'Швидкі відповіді та бліц-розрахунки' : 'Быстрые ответы и блиц-расчёты'}
          >
            <Zap className="w-3.5 h-3.5 fill-white" />
            <span className="hidden sm:inline">{lang === 'uk' ? 'Швидкі відповіді' : 'Быстрые ответы'}</span>
          </button>
        )}

        {/* Photo Math Scanner Button */}
        <button
          onClick={onOpenPhotoMath}
          className={`px-2 py-1 text-[11px] font-semibold rounded-md transition-all flex items-center gap-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-xs cursor-pointer active:scale-95`}
          title={getTranslation('photoMathDesc', lang)}
          aria-label={getTranslation('photoMath', lang)}
        >
          <Camera className="w-3.5 h-3.5" />
          <span className="hidden md:inline">{getTranslation('photoMath', lang)}</span>
        </button>

        {/* Language Switcher Dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowLangMenu(!showLangMenu)}
            className={`px-1.5 py-1 text-[11px] font-medium rounded-md transition-all flex items-center gap-1 ${
              isDark ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-200 text-slate-700'
            }`}
            title={getTranslation('changeLanguage', lang)}
          >
            <span>{currentLang.flag}</span>
            <span className="hidden sm:inline uppercase font-bold text-[10px]">{currentLang.code}</span>
          </button>

          {showLangMenu && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowLangMenu(false)}
              />
              <div
                className={`absolute right-0 top-full mt-1 z-50 py-1.5 rounded-xl shadow-2xl border min-w-[160px] max-h-72 overflow-y-auto backdrop-blur-md ${
                  isDark ? 'bg-slate-900/95 border-slate-700 text-slate-200' : 'bg-white/95 border-slate-200 text-slate-800'
                }`}
              >
                <div className="px-3 py-1 text-[10px] uppercase font-bold tracking-wider text-slate-400 border-b border-slate-700/30 mb-1">
                  Language / {currentLang.nativeName}
                </div>
                {LANGUAGES.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLang(l.code);
                      setShowLangMenu(false);
                    }}
                    className={`w-full px-3 py-1.5 text-left text-xs flex items-center justify-between transition-colors ${
                      lang === l.code
                        ? 'bg-blue-600 text-white font-bold'
                        : isDark
                        ? 'hover:bg-slate-800'
                        : 'hover:bg-slate-100'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span className="text-sm">{l.flag}</span>
                      <span className="truncate">{l.nativeName}</span>
                    </span>
                    <span className="text-[10px] uppercase opacity-60 font-mono">{l.code}</span>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Toggle OS Style */}
        <button
          onClick={() => setOsTheme(osTheme === 'windows' ? 'macos' : 'windows')}
          className={`px-1.5 sm:px-2 py-1 text-[11px] font-medium rounded-md transition-all flex items-center gap-1 ${
            isDark ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-200 text-slate-700'
          }`}
          title={getTranslation('changeOsTheme', lang)}
          aria-label={getTranslation('changeOsTheme', lang)}
        >
          <Laptop className="w-3.5 h-3.5" />
          <span className="hidden md:inline">
            {osTheme === 'windows' ? 'Win' : 'Mac'}
          </span>
        </button>

        {/* Settings button */}
        <button
          onClick={onOpenSettings}
          className={`p-1.5 rounded-md transition-colors ${
            isDark ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-200 text-slate-600'
          }`}
          title={getTranslation('settings', lang)}
          aria-label={getTranslation('settings', lang)}
        >
          <Settings className="w-3.5 h-3.5" />
        </button>

        {/* Shortcuts Guide */}
        <button
          onClick={onOpenShortcuts}
          className={`p-1.5 rounded-md transition-colors ${
            isDark ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-200 text-slate-600'
          }`}
          title={getTranslation('shortcuts', lang)}
          aria-label={getTranslation('shortcuts', lang)}
        >
          <HelpCircle className="w-3.5 h-3.5" />
        </button>

        {/* Sound toggle */}
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className={`p-1.5 rounded-md transition-colors ${
            soundEnabled
              ? 'text-blue-500 hover:bg-blue-500/10'
              : isDark
              ? 'hover:bg-slate-800 text-slate-400'
              : 'hover:bg-slate-200 text-slate-500'
          }`}
          title={soundEnabled ? getTranslation('soundOn', lang) : getTranslation('soundOff', lang)}
          aria-label={getTranslation('sound', lang)}
        >
          {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
        </button>

        {/* Dark/Light mode toggle */}
        <button
          onClick={() => setIsDark(!isDark)}
          className={`p-1.5 rounded-md transition-colors ${
            isDark ? 'hover:bg-slate-800 text-amber-400' : 'hover:bg-slate-200 text-indigo-600'
          }`}
          title={getTranslation('theme', lang)}
          aria-label={getTranslation('theme', lang)}
        >
          {isDark ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
        </button>

        {/* History Tape button with count badge */}
        <button
          onClick={() => setShowHistory(!showHistory)}
          className={`px-2 py-1 rounded-md text-xs font-medium flex items-center gap-1 transition-all ${
            showHistory
              ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/30'
              : isDark
              ? 'bg-slate-800/80 hover:bg-slate-800 text-slate-200'
              : 'bg-slate-200/80 hover:bg-slate-200 text-slate-800'
          }`}
          title={getTranslation('allSolutions', lang)}
          aria-label={getTranslation('allSolutions', lang)}
        >
          <History className="w-3.5 h-3.5" />
          <span className="text-[11px] font-semibold hidden sm:inline">
            {getTranslation('allSolutions', lang)}
          </span>
          {historyCount > 0 && (
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                showHistory ? 'bg-white/20 text-white' : 'bg-blue-500/20 text-blue-400'
              }`}
            >
              {historyCount}
            </span>
          )}
        </button>

        {/* Pin toggle */}
        <button
          onClick={() => setIsPinned(!isPinned)}
          className={`p-1.5 rounded-md transition-colors hidden sm:inline-flex ${
            isPinned
              ? 'text-blue-500 bg-blue-500/10'
              : isDark
              ? 'hover:bg-slate-800 text-slate-400'
              : 'hover:bg-slate-200 text-slate-500'
          }`}
          title={getTranslation('pinWindow', lang)}
          aria-label={getTranslation('pinWindow', lang)}
        >
          <Pin className="w-3.5 h-3.5" />
        </button>

        {/* Fullscreen / expand */}
        <button
          onClick={() => setIsFullscreen(!isFullscreen)}
          className={`p-1.5 rounded-md transition-colors hidden sm:inline-flex ${
            isDark ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-slate-200 text-slate-500'
          }`}
          title={getTranslation('fullscreen', lang)}
          aria-label={getTranslation('fullscreen', lang)}
        >
          {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
        </button>
      </div>
    </header>
  );
};
